<?php
/**
 * Plugin Name: Player Analytics
 * Description: سیستم آمارگیری پلیرهای صوتی
 * Version: 1.0.0
 * Author: Club Team
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    exit('Direct access not allowed');
}

// بارگذاری فایل‌های مورد نیاز
require_once plugin_dir_path(__FILE__) . 'player-analytics-handler.php';

// کلاس اصلی پلاگین
class PlayerAnalyticsPlugin {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_track_player_click', array($this, 'handle_ajax_request'));
        add_action('wp_ajax_nopriv_track_player_click', array($this, 'handle_ajax_request'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        
        // فعال‌سازی پلاگین
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        // ایجاد جدول در صورت عدم وجود
        $this->create_analytics_table();
    }
    
    public function activate() {
        // ایجاد جدول هنگام فعال‌سازی
        $this->create_analytics_table();
    }
    
    public function deactivate() {
        // پاک کردن داده‌ها در صورت نیاز
        // $this->cleanup_data();
    }
    
    public function enqueue_scripts() {
        // فقط در صفحاتی که پلیر دارند
        if (is_page() || is_single()) {
            wp_enqueue_script(
                'player-analytics',
                plugin_dir_url(__FILE__) . 'landings_assets/js/player-analytics.js',
                array('jquery'),
                '1.0.0',
                true
            );
            
            // ارسال تنظیمات به JavaScript
            wp_localize_script('player-analytics', 'playerAnalyticsConfig', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('player_analytics_nonce'),
                'debug' => WP_DEBUG
            ));
        }
    }
    
    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'player-analytics') !== false) {
            wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.9.1', true);
            wp_enqueue_style('player-analytics-admin', plugin_dir_url(__FILE__) . 'admin-styles.css', array(), '1.0.0');
        }
    }
    
    public function handle_ajax_request() {
        // بررسی nonce
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'player_analytics_nonce')) {
            wp_send_json_error('Security check failed');
        }
        
        $action = sanitize_text_field($_POST['analytics_action'] ?? '');
        $analytics_db = new PlayerAnalyticsDB();
        
        switch ($action) {
            case 'save_click':
                $data = json_decode(stripslashes($_POST['data'] ?? '{}'), true);
                if ($data && isset($data['id'], $data['action'], $data['playerData'])) {
                    $result = $analytics_db->save_click($data);
                    wp_send_json_success(array('saved' => $result));
                } else {
                    wp_send_json_error('Invalid data format');
                }
                break;
                
            case 'get_stats':
                $stats = $analytics_db->get_overall_stats();
                wp_send_json_success($stats);
                break;
                
            case 'get_player_stats':
                $player_title = sanitize_text_field($_POST['player_title'] ?? '');
                $stats = $analytics_db->get_player_detailed_stats($player_title);
                wp_send_json_success($stats);
                break;
                
            case 'get_time_stats':
                $days = intval($_POST['days'] ?? 7);
                $stats = $analytics_db->get_time_based_stats($days);
                wp_send_json_success($stats);
                break;
                
            case 'get_recent':
                $limit = intval($_POST['limit'] ?? 50);
                $clicks = $analytics_db->get_recent_clicks($limit);
                wp_send_json_success($clicks);
                break;
                
            default:
                wp_send_json_error('Invalid action');
        }
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'آمار پلیرها',
            'آمار پلیرها',
            'manage_options',
            'player-analytics',
            array($this, 'admin_page'),
            'dashicons-chart-bar',
            30
        );
        
        add_submenu_page(
            'player-analytics',
            'گزارش تفصیلی',
            'گزارش تفصیلی',
            'manage_options',
            'player-analytics-detailed',
            array($this, 'detailed_report_page')
        );
        
        add_submenu_page(
            'player-analytics',
            'صادرات داده',
            'صادرات داده',
            'manage_options',
            'player-analytics-export',
            array($this, 'export_page')
        );
    }
    
    public function admin_page() {
        $analytics_db = new PlayerAnalyticsDB();
        $stats = $analytics_db->get_overall_stats();
        $recent_clicks = $analytics_db->get_recent_clicks(20);
        $time_stats = $analytics_db->get_time_based_stats(7);
        ?>
        <div class="wrap">
            <h1>آمار پلیرها</h1>
            
            <div class="player-analytics-dashboard">
                <!-- آمار کلی -->
                <div class="stats-overview">
                    <h2>آمار کلی</h2>
                    <div class="stats-grid">
                        <div class="stat-box">
                            <h3><?php echo number_format($stats['total_clicks']); ?></h3>
                            <p>تعداد کل کلیک‌ها</p>
                        </div>
                        <div class="stat-box">
                            <h3><?php echo number_format($stats['unique_sessions']); ?></h3>
                            <p>جلسات منحصر به فرد</p>
                        </div>
                        <div class="stat-box">
                            <h3><?php echo number_format($stats['unique_players']); ?></h3>
                            <p>پلیرهای منحصر به فرد</p>
                        </div>
                    </div>
                </div>
                
                <!-- آمار بر اساس نوع عمل -->
                <div class="action-stats">
                    <h2>آمار بر اساس نوع عمل</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>نوع عمل</th>
                                <th>تعداد</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stats['by_action'] as $action => $count): ?>
                            <tr>
                                <td><?php echo esc_html($action); ?></td>
                                <td><?php echo number_format($count); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- آمار بر اساس پلیر -->
                <div class="player-stats">
                    <h2>آمار بر اساس پلیر</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>نام پلیر</th>
                                <th>تعداد کلیک</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stats['by_player'] as $player => $count): ?>
                            <tr>
                                <td><?php echo esc_html($player); ?></td>
                                <td><?php echo number_format($count); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- آمار بر اساس دستگاه -->
                <div class="device-stats">
                    <h2>آمار بر اساس دستگاه</h2>
                    <div class="device-grid">
                        <div class="device-box">
                            <h3><?php echo number_format($stats['by_device']['mobile']); ?></h3>
                            <p>موبایل</p>
                        </div>
                        <div class="device-box">
                            <h3><?php echo number_format($stats['by_device']['desktop']); ?></h3>
                            <p>دسکتاپ</p>
                        </div>
                    </div>
                </div>
                
                <!-- آخرین کلیک‌ها -->
                <div class="recent-clicks">
                    <h2>آخرین کلیک‌ها</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>زمان</th>
                                <th>پلیر</th>
                                <th>عمل</th>
                                <th>دستگاه</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_clicks as $click): ?>
                            <tr>
                                <td><?php echo esc_html($click['timestamp']); ?></td>
                                <td><?php echo esc_html($click['player_title']); ?></td>
                                <td><?php echo esc_html($click['action']); ?></td>
                                <td><?php echo $click['is_mobile'] ? 'موبایل' : 'دسکتاپ'; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <style>
            .stats-grid, .device-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .stat-box, .device-box {
                background: #f1f1f1;
                padding: 20px;
                border-radius: 8px;
                text-align: center;
            }
            .stat-box h3, .device-box h3 {
                font-size: 2em;
                margin: 0 0 10px 0;
                color: #0073aa;
            }
            .stat-box p, .device-box p {
                margin: 0;
                color: #666;
            }
            .player-analytics-dashboard > div {
                margin: 30px 0;
            }
            </style>
        </div>
        <?php
    }
    
    public function detailed_report_page() {
        // هدایت به صفحه گزارش تفصیلی
        $report_url = plugin_dir_url(__FILE__) . 'player-analytics-report.php';
        echo '<script>window.location.href = "' . esc_url($report_url) . '";</script>';
    }
    
    public function export_page() {
        $analytics_db = new PlayerAnalyticsDB();
        $stats = $analytics_db->get_overall_stats();
        $recent_clicks = $analytics_db->get_recent_clicks(1000);
        
        if (isset($_POST['export_format'])) {
            $format = sanitize_text_field($_POST['export_format']);
            $this->export_data($stats, $recent_clicks, $format);
        }
        ?>
        <div class="wrap">
            <h1>صادرات داده‌های آمار</h1>
            
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row">فرمت صادرات</th>
                        <td>
                            <select name="export_format">
                                <option value="csv">CSV</option>
                                <option value="json">JSON</option>
                                <option value="excel">Excel</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">تعداد رکوردها</th>
                        <td>
                            <input type="number" name="record_limit" value="1000" min="1" max="10000">
                        </td>
                    </tr>
                </table>
                
                <?php wp_nonce_field('export_analytics_data'); ?>
                <p class="submit">
                    <input type="submit" class="button-primary" value="صادرات">
                </p>
            </form>
        </div>
        <?php
    }
    
    private function export_data($stats, $clicks, $format) {
        $filename = 'player-analytics-' . date('Y-m-d-H-i-s');
        
        switch ($format) {
            case 'csv':
                $this->export_csv($stats, $clicks, $filename);
                break;
            case 'json':
                $this->export_json($stats, $clicks, $filename);
                break;
            case 'excel':
                $this->export_excel($stats, $clicks, $filename);
                break;
        }
    }
    
    private function export_csv($stats, $clicks, $filename) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        // آمار کلی
        fputcsv($output, array('نوع آمار', 'مقدار'));
        fputcsv($output, array('تعداد کل کلیک‌ها', $stats['total_clicks']));
        fputcsv($output, array('جلسات منحصر به فرد', $stats['unique_sessions']));
        fputcsv($output, array('پلیرهای منحصر به فرد', $stats['unique_players']));
        
        fputcsv($output, array('')); // خط خالی
        
        // آمار بر اساس نوع عمل
        fputcsv($output, array('نوع عمل', 'تعداد'));
        foreach ($stats['by_action'] as $action => $count) {
            fputcsv($output, array($action, $count));
        }
        
        fputcsv($output, array('')); // خط خالی
        
        // آمار بر اساس پلیر
        fputcsv($output, array('نام پلیر', 'تعداد کلیک'));
        foreach ($stats['by_player'] as $player => $count) {
            fputcsv($output, array($player, $count));
        }
        
        fputcsv($output, array('')); // خط خالی
        
        // آخرین کلیک‌ها
        fputcsv($output, array('زمان', 'پلیر', 'عمل', 'دستگاه', 'شناسه جلسه'));
        foreach ($clicks as $click) {
            fputcsv($output, array(
                $click['timestamp'],
                $click['player_title'],
                $click['action'],
                $click['is_mobile'] ? 'موبایل' : 'دسکتاپ',
                $click['session_id']
            ));
        }
        
        fclose($output);
        exit;
    }
    
    private function export_json($stats, $clicks, $filename) {
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.json"');
        
        $data = array(
            'export_info' => array(
                'exported_at' => date('Y-m-d H:i:s'),
                'total_records' => count($clicks)
            ),
            'overall_stats' => $stats,
            'recent_clicks' => $clicks
        );
        
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    private function export_excel($stats, $clicks, $filename) {
        // برای Excel نیاز به کتابخانه‌ای مثل PhpSpreadsheet است
        // در اینجا فقط CSV با پسوند xlsx ارسال می‌کنیم
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
        
        // ساده‌ترین راه: CSV با پسوند xlsx
        $this->export_csv($stats, $clicks, $filename);
    }
    
    private function create_analytics_table() {
        $analytics_db = new PlayerAnalyticsDB();
        $analytics_db->create_table();
    }
}

// مقداردهی اولیه
new PlayerAnalyticsPlugin();
?>

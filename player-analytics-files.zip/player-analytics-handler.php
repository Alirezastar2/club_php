<?php
/**
 * مدیریت آمار پلیرها
 * Player Analytics Handler
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

// تنظیمات پایگاه داده
class PlayerAnalyticsDB {
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'player_analytics';
    }
    
    // ایجاد جدول آمار
    public function create_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            click_id varchar(100) NOT NULL,
            session_id varchar(100) NOT NULL,
            action varchar(50) NOT NULL,
            player_title varchar(255) NOT NULL,
            audio_src text,
            audio_duration decimal(10,2) DEFAULT 0,
            user_agent text,
            screen_resolution varchar(50),
            viewport_size varchar(50),
            is_mobile tinyint(1) DEFAULT 0,
            referrer text,
            page_url text,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY click_id (click_id),
            KEY session_id (session_id),
            KEY action (action),
            KEY player_title (player_title),
            KEY timestamp (timestamp)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    // ذخیره داده آمار
    public function save_click($data) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'click_id' => sanitize_text_field($data['id']),
                'session_id' => sanitize_text_field($data['sessionId']),
                'action' => sanitize_text_field($data['action']),
                'player_title' => sanitize_text_field($data['playerData']['title']),
                'audio_src' => esc_url_raw($data['playerData']['audioSrc']),
                'audio_duration' => floatval($data['playerData']['audioDuration']),
                'user_agent' => sanitize_text_field($data['playerData']['userAgent']),
                'screen_resolution' => sanitize_text_field($data['playerData']['screenResolution']),
                'viewport_size' => sanitize_text_field($data['playerData']['viewportSize']),
                'is_mobile' => $data['playerData']['isMobile'] ? 1 : 0,
                'referrer' => esc_url_raw($data['playerData']['referrer']),
                'page_url' => esc_url_raw($data['playerData']['url']),
                'timestamp' => sanitize_text_field($data['timestamp'])
            ),
            array(
                '%s', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%d', '%s', '%s', '%s'
            )
        );
        
        return $result !== false;
    }
    
    // دریافت آمار کلی
    public function get_overall_stats() {
        global $wpdb;
        
        $stats = array();
        
        // آمار کلی
        $total_clicks = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        $unique_sessions = $wpdb->get_var("SELECT COUNT(DISTINCT session_id) FROM {$this->table_name}");
        $unique_players = $wpdb->get_var("SELECT COUNT(DISTINCT player_title) FROM {$this->table_name}");
        
        $stats['total_clicks'] = intval($total_clicks);
        $stats['unique_sessions'] = intval($unique_sessions);
        $stats['unique_players'] = intval($unique_players);
        
        // آمار بر اساس نوع عمل
        $action_stats = $wpdb->get_results("
            SELECT action, COUNT(*) as count 
            FROM {$this->table_name} 
            GROUP BY action 
            ORDER BY count DESC
        ", ARRAY_A);
        
        $stats['by_action'] = array();
        foreach ($action_stats as $row) {
            $stats['by_action'][$row['action']] = intval($row['count']);
        }
        
        // آمار بر اساس پلیر
        $player_stats = $wpdb->get_results("
            SELECT player_title, COUNT(*) as count 
            FROM {$this->table_name} 
            GROUP BY player_title 
            ORDER BY count DESC
        ", ARRAY_A);
        
        $stats['by_player'] = array();
        foreach ($player_stats as $row) {
            $stats['by_player'][$row['player_title']] = intval($row['count']);
        }
        
        // آمار بر اساس دستگاه
        $device_stats = $wpdb->get_results("
            SELECT is_mobile, COUNT(*) as count 
            FROM {$this->table_name} 
            GROUP BY is_mobile
        ", ARRAY_A);
        
        $stats['by_device'] = array(
            'mobile' => 0,
            'desktop' => 0
        );
        foreach ($device_stats as $row) {
            if ($row['is_mobile']) {
                $stats['by_device']['mobile'] = intval($row['count']);
            } else {
                $stats['by_device']['desktop'] = intval($row['count']);
            }
        }
        
        return $stats;
    }
    
    // دریافت آمار تفصیلی پلیر
    public function get_player_detailed_stats($player_title = null) {
        global $wpdb;
        
        $where_clause = $player_title ? $wpdb->prepare("WHERE player_title = %s", $player_title) : "";
        
        $stats = $wpdb->get_results("
            SELECT 
                player_title,
                action,
                COUNT(*) as count,
                COUNT(DISTINCT session_id) as unique_sessions
            FROM {$this->table_name} 
            {$where_clause}
            GROUP BY player_title, action 
            ORDER BY player_title, count DESC
        ", ARRAY_A);
        
        return $stats;
    }
    
    // دریافت آمار زمانی
    public function get_time_based_stats($days = 7) {
        global $wpdb;
        
        $stats = $wpdb->get_results($wpdb->prepare("
            SELECT 
                DATE(timestamp) as date,
                COUNT(*) as total_clicks,
                COUNT(DISTINCT session_id) as unique_sessions,
                COUNT(DISTINCT player_title) as unique_players
            FROM {$this->table_name} 
            WHERE timestamp >= DATE_SUB(NOW(), INTERVAL %d DAY)
            GROUP BY DATE(timestamp) 
            ORDER BY date DESC
        ", $days), ARRAY_A);
        
        return $stats;
    }
    
    // دریافت آخرین کلیک‌ها
    public function get_recent_clicks($limit = 50) {
        global $wpdb;
        
        $clicks = $wpdb->get_results($wpdb->prepare("
            SELECT 
                click_id,
                session_id,
                action,
                player_title,
                is_mobile,
                timestamp
            FROM {$this->table_name} 
            ORDER BY timestamp DESC 
            LIMIT %d
        ", $limit), ARRAY_A);
        
        return $clicks;
    }
}

// مدیریت درخواست‌های AJAX
function handle_player_analytics_ajax() {
    // بررسی nonce برای امنیت
    if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'player_analytics_nonce')) {
        wp_die('Security check failed');
    }
    
    $action = sanitize_text_field($_POST['analytics_action'] ?? '');
    $analytics_db = new PlayerAnalyticsDB();
    
    switch ($action) {
        case 'save_click':
            $data = json_decode(stripslashes($_POST['data'] ?? '{}'), true);
            if ($data && isset($data['id'], $data['action'], $data['playerData'])) {
                $result = $analytics_db->save_click($data);
                wp_send_json_success(array('saved' => $result));
            } else {
                wp_send_json_error('Invalid data format');
            }
            break;
            
        case 'get_stats':
            $stats = $analytics_db->get_overall_stats();
            wp_send_json_success($stats);
            break;
            
        case 'get_player_stats':
            $player_title = sanitize_text_field($_POST['player_title'] ?? '');
            $stats = $analytics_db->get_player_detailed_stats($player_title);
            wp_send_json_success($stats);
            break;
            
        case 'get_time_stats':
            $days = intval($_POST['days'] ?? 7);
            $stats = $analytics_db->get_time_based_stats($days);
            wp_send_json_success($stats);
            break;
            
        case 'get_recent':
            $limit = intval($_POST['limit'] ?? 50);
            $clicks = $analytics_db->get_recent_clicks($limit);
            wp_send_json_success($clicks);
            break;
            
        default:
            wp_send_json_error('Invalid action');
    }
}

// اتصال به WordPress hooks
add_action('wp_ajax_track_player_click', 'handle_player_analytics_ajax');
add_action('wp_ajax_nopriv_track_player_click', 'handle_player_analytics_ajax');

// ایجاد جدول در فعال‌سازی پلاگین
function create_player_analytics_table() {
    $analytics_db = new PlayerAnalyticsDB();
    $analytics_db->create_table();
}
add_action('init', 'create_player_analytics_table');

// اضافه کردن منوی مدیریت
function add_player_analytics_admin_menu() {
    add_menu_page(
        'آمار پلیرها',
        'آمار پلیرها',
        'manage_options',
        'player-analytics',
        'player_analytics_admin_page',
        'dashicons-chart-bar',
        30
    );
}
add_action('admin_menu', 'add_player_analytics_admin_menu');

// صفحه مدیریت آمار
function player_analytics_admin_page() {
    $analytics_db = new PlayerAnalyticsDB();
    $stats = $analytics_db->get_overall_stats();
    $recent_clicks = $analytics_db->get_recent_clicks(20);
    $time_stats = $analytics_db->get_time_based_stats(7);
    ?>
    <div class="wrap">
        <h1>آمار پلیرها</h1>
        
        <div class="player-analytics-dashboard">
            <!-- آمار کلی -->
            <div class="stats-overview">
                <h2>آمار کلی</h2>
                <div class="stats-grid">
                    <div class="stat-box">
                        <h3><?php echo number_format($stats['total_clicks']); ?></h3>
                        <p>تعداد کل کلیک‌ها</p>
                    </div>
                    <div class="stat-box">
                        <h3><?php echo number_format($stats['unique_sessions']); ?></h3>
                        <p>جلسات منحصر به فرد</p>
                    </div>
                    <div class="stat-box">
                        <h3><?php echo number_format($stats['unique_players']); ?></h3>
                        <p>پلیرهای منحصر به فرد</p>
                    </div>
                </div>
            </div>
            
            <!-- آمار بر اساس نوع عمل -->
            <div class="action-stats">
                <h2>آمار بر اساس نوع عمل</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>نوع عمل</th>
                            <th>تعداد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['by_action'] as $action => $count): ?>
                        <tr>
                            <td><?php echo esc_html($action); ?></td>
                            <td><?php echo number_format($count); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- آمار بر اساس پلیر -->
            <div class="player-stats">
                <h2>آمار بر اساس پلیر</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>نام پلیر</th>
                            <th>تعداد کلیک</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['by_player'] as $player => $count): ?>
                        <tr>
                            <td><?php echo esc_html($player); ?></td>
                            <td><?php echo number_format($count); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- آمار بر اساس دستگاه -->
            <div class="device-stats">
                <h2>آمار بر اساس دستگاه</h2>
                <div class="device-grid">
                    <div class="device-box">
                        <h3><?php echo number_format($stats['by_device']['mobile']); ?></h3>
                        <p>موبایل</p>
                    </div>
                    <div class="device-box">
                        <h3><?php echo number_format($stats['by_device']['desktop']); ?></h3>
                        <p>دسکتاپ</p>
                    </div>
                </div>
            </div>
            
            <!-- آخرین کلیک‌ها -->
            <div class="recent-clicks">
                <h2>آخرین کلیک‌ها</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>زمان</th>
                            <th>پلیر</th>
                            <th>عمل</th>
                            <th>دستگاه</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_clicks as $click): ?>
                        <tr>
                            <td><?php echo esc_html($click['timestamp']); ?></td>
                            <td><?php echo esc_html($click['player_title']); ?></td>
                            <td><?php echo esc_html($click['action']); ?></td>
                            <td><?php echo $click['is_mobile'] ? 'موبایل' : 'دسکتاپ'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <style>
        .stats-grid, .device-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-box, .device-box {
            background: #f1f1f1;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-box h3, .device-box h3 {
            font-size: 2em;
            margin: 0 0 10px 0;
            color: #0073aa;
        }
        .stat-box p, .device-box p {
            margin: 0;
            color: #666;
        }
        .player-analytics-dashboard > div {
            margin: 30px 0;
        }
        </style>
    </div>
    <?php
}
?>

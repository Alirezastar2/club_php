<?php
/**
 * صفحه صادرات داده‌های آمار
 * Player Analytics Export Page
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

// بارگذاری handler آمار
require_once 'player-analytics-handler.php';

// ایجاد اتصال به پایگاه داده
$analytics_db = new PlayerAnalyticsDB();

// دریافت آمار
$stats = $analytics_db->get_overall_stats();
$recent_clicks = $analytics_db->get_recent_clicks(1000);

// پردازش صادرات
if (isset($_POST['export_format'])) {
    $format = sanitize_text_field($_POST['export_format']);
    $limit = intval($_POST['record_limit'] ?? 1000);
    
    // دریافت داده‌ها بر اساس محدودیت
    $clicks = $analytics_db->get_recent_clicks($limit);
    
    switch ($format) {
        case 'csv':
            export_csv($stats, $clicks);
            break;
        case 'json':
            export_json($stats, $clicks);
            break;
        case 'excel':
            export_excel($stats, $clicks);
            break;
    }
}

// تابع صادرات CSV
function export_csv($stats, $clicks) {
    $filename = 'player-analytics-' . date('Y-m-d-H-i-s') . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    // آمار کلی
    fputcsv($output, array('نوع آمار', 'مقدار'));
    fputcsv($output, array('تعداد کل کلیک‌ها', $stats['total_clicks']));
    fputcsv($output, array('جلسات منحصر به فرد', $stats['unique_sessions']));
    fputcsv($output, array('پلیرهای منحصر به فرد', $stats['unique_players']));
    
    fputcsv($output, array('')); // خط خالی
    
    // آمار بر اساس نوع عمل
    fputcsv($output, array('نوع عمل', 'تعداد'));
    foreach ($stats['by_action'] as $action => $count) {
        fputcsv($output, array($action, $count));
    }
    
    fputcsv($output, array('')); // خط خالی
    
    // آمار بر اساس پلیر
    fputcsv($output, array('نام پلیر', 'تعداد کلیک'));
    foreach ($stats['by_player'] as $player => $count) {
        fputcsv($output, array($player, $count));
    }
    
    fputcsv($output, array('')); // خط خالی
    
    // آخرین کلیک‌ها
    fputcsv($output, array('زمان', 'پلیر', 'عمل', 'دستگاه', 'شناسه جلسه'));
    foreach ($clicks as $click) {
        fputcsv($output, array(
            $click['timestamp'],
            $click['player_title'],
            $click['action'],
            $click['is_mobile'] ? 'موبایل' : 'دسکتاپ',
            $click['session_id']
        ));
    }
    
    fclose($output);
    exit;
}

// تابع صادرات JSON
function export_json($stats, $clicks) {
    $filename = 'player-analytics-' . date('Y-m-d-H-i-s') . '.json';
    
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $data = array(
        'export_info' => array(
            'exported_at' => date('Y-m-d H:i:s'),
            'total_records' => count($clicks),
            'export_format' => 'JSON'
        ),
        'overall_stats' => $stats,
        'recent_clicks' => $clicks
    );
    
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// تابع صادرات Excel
function export_excel($stats, $clicks) {
    $filename = 'player-analytics-' . date('Y-m-d-H-i-s') . '.xlsx';
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    // ساده‌ترین راه: CSV با پسوند xlsx
    export_csv($stats, $clicks);
}

?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صادرات داده‌های آمار</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tahoma', 'Arial', sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .nav-menu {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nav-menu ul {
            list-style: none;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .nav-menu a {
            color: #28a745;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .nav-menu a:hover {
            background: #f8f9fa;
        }
        
        .export-form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        
        .form-group select,
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: #28a745;
        }
        
        .btn {
            background: #28a745;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #218838;
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .stats-preview {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .stat-item {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .stat-item h4 {
            font-size: 1.5em;
            color: #28a745;
            margin-bottom: 5px;
        }
        
        .stat-item p {
            color: #666;
            font-size: 0.9em;
        }
        
        @media (max-width: 768px) {
            .nav-menu ul {
                flex-direction: column;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- هدر -->
        <div class="header">
            <h1>صادرات داده‌های آمار</h1>
            <p>دانلود آمار پلیرها در فرمت‌های مختلف</p>
        </div>
        
        <!-- منوی ناوبری -->
        <div class="nav-menu">
            <ul>
                <li><a href="player-analytics-dashboard.php">داشبورد</a></li>
                <li><a href="player-analytics-report.php">گزارش تفصیلی</a></li>
                <li><a href="player-analytics-export.php">صادرات داده</a></li>
                <li><a href="player-analytics-test.php">تست سیستم</a></li>
            </ul>
        </div>
        
        <!-- پیش‌نمایش آمار -->
        <div class="stats-preview">
            <h2>پیش‌نمایش آمار</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <h4><?php echo number_format($stats['total_clicks']); ?></h4>
                    <p>تعداد کل کلیک‌ها</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format($stats['unique_sessions']); ?></h4>
                    <p>جلسات منحصر به فرد</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format($stats['unique_players']); ?></h4>
                    <p>پلیرهای منحصر به فرد</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format(count($recent_clicks)); ?></h4>
                    <p>رکوردهای موجود</p>
                </div>
            </div>
        </div>
        
        <!-- فرم صادرات -->
        <div class="export-form">
            <h2>تنظیمات صادرات</h2>
            <form method="post">
                <div class="form-group">
                    <label for="export_format">فرمت صادرات:</label>
                    <select name="export_format" id="export_format" required>
                        <option value="">انتخاب فرمت</option>
                        <option value="csv">CSV (Excel)</option>
                        <option value="json">JSON</option>
                        <option value="excel">Excel (XLSX)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="record_limit">تعداد رکوردها:</label>
                    <input type="number" name="record_limit" id="record_limit" value="1000" min="1" max="10000" required>
                    <small>حداکثر 10,000 رکورد</small>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="btn">صادرات داده</button>
                    <a href="player-analytics-dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: inline-block; margin-right: 10px;">بازگشت به داشبورد</a>
                </div>
            </form>
        </div>
        
        <!-- راهنمای استفاده -->
        <div class="stats-preview">
            <h2>راهنمای استفاده</h2>
            <ul style="margin-top: 15px; padding-right: 20px;">
                <li><strong>CSV:</strong> مناسب برای Excel و Google Sheets</li>
                <li><strong>JSON:</strong> مناسب برای برنامه‌نویسی و تحلیل داده</li>
                <li><strong>Excel:</strong> فایل Excel با فرمت XLSX</li>
            </ul>
        </div>
    </div>
</body>
</html>

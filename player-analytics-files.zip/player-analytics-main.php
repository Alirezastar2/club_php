<?php
/**
 * فایل اصلی سیستم آمار پلیرها
 * Player Analytics Main File
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

// بارگذاری handler آمار
require_once 'player-analytics-handler.php';

// کلاس اصلی آمار
class PlayerAnalyticsMain {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_track_player_click', array($this, 'handle_ajax_request'));
        add_action('wp_ajax_nopriv_track_player_click', array($this, 'handle_ajax_request'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    
    public function init() {
        // ایجاد جدول در صورت عدم وجود
        $this->create_analytics_table();
    }
    
    public function enqueue_scripts() {
        // فقط در صفحاتی که پلیر دارند
        if (is_page() || is_single()) {
            wp_enqueue_script(
                'player-analytics',
                get_stylesheet_directory_uri() . '/jannah-child/landings_assets/js/player-analytics.js',
                array('jquery'),
                '1.0.0',
                true
            );
            
            // ارسال تنظیمات به JavaScript
            wp_localize_script('player-analytics', 'playerAnalyticsConfig', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('player_analytics_nonce'),
                'debug' => WP_DEBUG
            ));
        }
    }
    
    public function handle_ajax_request() {
        // بررسی nonce
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'player_analytics_nonce')) {
            wp_send_json_error('Security check failed');
        }
        
        $action = sanitize_text_field($_POST['analytics_action'] ?? '');
        $analytics_db = new PlayerAnalyticsDB();
        
        switch ($action) {
            case 'save_click':
                $data = json_decode(stripslashes($_POST['data'] ?? '{}'), true);
                if ($data && isset($data['id'], $data['action'], $data['playerData'])) {
                    $result = $analytics_db->save_click($data);
                    wp_send_json_success(array('saved' => $result));
                } else {
                    wp_send_json_error('Invalid data format');
                }
                break;
                
            case 'get_stats':
                $stats = $analytics_db->get_overall_stats();
                wp_send_json_success($stats);
                break;
                
            case 'get_player_stats':
                $player_title = sanitize_text_field($_POST['player_title'] ?? '');
                $stats = $analytics_db->get_player_detailed_stats($player_title);
                wp_send_json_success($stats);
                break;
                
            case 'get_time_stats':
                $days = intval($_POST['days'] ?? 7);
                $stats = $analytics_db->get_time_based_stats($days);
                wp_send_json_success($stats);
                break;
                
            case 'get_recent':
                $limit = intval($_POST['limit'] ?? 50);
                $clicks = $analytics_db->get_recent_clicks($limit);
                wp_send_json_success($clicks);
                break;
                
            default:
                wp_send_json_error('Invalid action');
        }
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'آمار پلیرها',
            'آمار پلیرها',
            'manage_options',
            'player-analytics',
            array($this, 'admin_page'),
            'dashicons-chart-bar',
            30
        );
    }
    
    public function admin_page() {
        // هدایت به صفحه داشبورد
        $dashboard_url = get_stylesheet_directory_uri() . '/jannah-child/player-analytics-dashboard.php';
        echo '<script>window.location.href = "' . esc_url($dashboard_url) . '";</script>';
    }
    
    private function create_analytics_table() {
        $analytics_db = new PlayerAnalyticsDB();
        $analytics_db->create_table();
    }
}

// مقداردهی اولیه
new PlayerAnalyticsMain();
?>

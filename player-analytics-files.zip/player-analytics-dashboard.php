<?php
/**
 * داشبورد آمار پلیرها
 * Player Analytics Dashboard
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

// بارگذاری handler آمار
require_once 'player-analytics-handler.php';

// ایجاد اتصال به پایگاه داده
$analytics_db = new PlayerAnalyticsDB();

// دریافت آمار
$stats = $analytics_db->get_overall_stats();
$recent_clicks = $analytics_db->get_recent_clicks(20);
$time_stats = $analytics_db->get_time_based_stats(7);

?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد آمار پلیرها</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tahoma', 'Arial', sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .nav-menu {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nav-menu ul {
            list-style: none;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .nav-menu a {
            color: #667eea;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .nav-menu a:hover {
            background: #f8f9fa;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            font-size: 2.5em;
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .stat-card p {
            color: #666;
            font-size: 1.1em;
        }
        
        .chart-container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .chart-title {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: #333;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 15px;
            text-align: right;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background: #f8f9fa;
            font-weight: bold;
            color: #555;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-left: 10px;
        }
        
        .status-active {
            background: #28a745;
        }
        
        .status-inactive {
            background: #dc3545;
        }
        
        @media (max-width: 768px) {
            .nav-menu ul {
                flex-direction: column;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .container {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- هدر -->
        <div class="header">
            <h1>داشبورد آمار پلیرها</h1>
            <p>آمار کامل کلیک‌ها و تعاملات کاربران با پلیرهای صوتی</p>
        </div>
        
        <!-- منوی ناوبری -->
        <div class="nav-menu">
            <ul>
                <li><a href="player-analytics-dashboard.php">داشبورد</a></li>
                <li><a href="player-analytics-report.php">گزارش تفصیلی</a></li>
                <li><a href="player-analytics-export.php">صادرات داده</a></li>
                <li><a href="player-analytics-test.php">تست سیستم</a></li>
            </ul>
        </div>
        
        <!-- آمار کلی -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo number_format($stats['total_clicks']); ?></h3>
                <p>تعداد کل کلیک‌ها</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($stats['unique_sessions']); ?></h3>
                <p>جلسات منحصر به فرد</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($stats['unique_players']); ?></h3>
                <p>پلیرهای منحصر به فرد</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($stats['by_device']['mobile']); ?></h3>
                <p>کلیک‌های موبایل</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($stats['by_device']['desktop']); ?></h3>
                <p>کلیک‌های دسکتاپ</p>
            </div>
        </div>
        
        <!-- آمار بر اساس نوع عمل -->
        <div class="chart-container">
            <h2 class="chart-title">آمار بر اساس نوع عمل</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>نوع عمل</th>
                            <th>تعداد</th>
                            <th>درصد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_actions = array_sum($stats['by_action']);
                        foreach ($stats['by_action'] as $action => $count): 
                            $percentage = $total_actions > 0 ? round(($count / $total_actions) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><?php echo esc_html($action); ?></td>
                            <td><?php echo number_format($count); ?></td>
                            <td><?php echo $percentage; ?>%</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- آمار بر اساس پلیر -->
        <div class="chart-container">
            <h2 class="chart-title">آمار بر اساس پلیر</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>نام پلیر</th>
                            <th>تعداد کلیک</th>
                            <th>درصد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_players = array_sum($stats['by_player']);
                        foreach ($stats['by_player'] as $player => $count): 
                            $percentage = $total_players > 0 ? round(($count / $total_players) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><?php echo esc_html($player); ?></td>
                            <td><?php echo number_format($count); ?></td>
                            <td><?php echo $percentage; ?>%</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- آخرین کلیک‌ها -->
        <div class="chart-container">
            <h2 class="chart-title">آخرین کلیک‌ها</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>زمان</th>
                            <th>پلیر</th>
                            <th>عمل</th>
                            <th>دستگاه</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_clicks as $click): ?>
                        <tr>
                            <td><?php echo esc_html($click['timestamp']); ?></td>
                            <td><?php echo esc_html($click['player_title']); ?></td>
                            <td><?php echo esc_html($click['action']); ?></td>
                            <td>
                                <?php echo $click['is_mobile'] ? 'موبایل' : 'دسکتاپ'; ?>
                                <span class="status-indicator <?php echo $click['is_mobile'] ? 'status-active' : 'status-inactive'; ?>"></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- وضعیت سیستم -->
        <div class="chart-container">
            <h2 class="chart-title">وضعیت سیستم</h2>
            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 200px;">
                    <h3>وضعیت کلی</h3>
                    <p>
                        <?php if ($stats['total_clicks'] > 0): ?>
                            <span class="status-indicator status-active"></span>
                            سیستم فعال و داده‌هایی جمع‌آوری شده است
                        <?php else: ?>
                            <span class="status-indicator status-inactive"></span>
                            سیستم آماده است اما هنوز داده‌ای جمع‌آوری نشده است
                        <?php endif; ?>
                    </p>
                </div>
                <div style="flex: 1; min-width: 200px;">
                    <h3>آخرین به‌روزرسانی</h3>
                    <p><?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
/**
 * تست سیستم آمار پلیرها
 * Player Analytics Test Page
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

// بارگذاری handler آمار
require_once 'player-analytics-handler.php';

// ایجاد اتصال به پایگاه داده
$analytics_db = new PlayerAnalyticsDB();

// ایجاد جدول در صورت عدم وجود
$analytics_db->create_table();

// دریافت آمار
$stats = $analytics_db->get_overall_stats();
$recent_clicks = $analytics_db->get_recent_clicks(10);

// تست اتصال به پایگاه داده
$db_test = $analytics_db->get_overall_stats();
$db_status = !empty($db_test) ? 'success' : 'error';

?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تست سیستم آمار پلیرها</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tahoma', 'Arial', sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .nav-menu {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nav-menu ul {
            list-style: none;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .nav-menu a {
            color: #17a2b8;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .nav-menu a:hover {
            background: #f8f9fa;
        }
        
        .test-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .test-section h2 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .status-card {
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border: 2px solid;
        }
        
        .status-success {
            background: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        
        .status-error {
            background: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        
        .status-warning {
            background: #fff3cd;
            border-color: #ffeaa7;
            color: #856404;
        }
        
        .status-info {
            background: #d1ecf1;
            border-color: #bee5eb;
            color: #0c5460;
        }
        
        .status-card h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }
        
        .status-card p {
            margin: 0;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .stat-item {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .stat-item h4 {
            font-size: 1.5em;
            color: #17a2b8;
            margin-bottom: 5px;
        }
        
        .stat-item p {
            color: #666;
            font-size: 0.9em;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            padding: 12px;
            text-align: right;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background: #f8f9fa;
            font-weight: bold;
            color: #555;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .test-instructions {
            background: #e7f3ff;
            padding: 20px;
            border-radius: 8px;
            border-right: 4px solid #17a2b8;
        }
        
        .test-instructions h3 {
            color: #17a2b8;
            margin-bottom: 15px;
        }
        
        .test-instructions ul {
            margin-right: 20px;
        }
        
        .test-instructions li {
            margin-bottom: 8px;
        }
        
        @media (max-width: 768px) {
            .nav-menu ul {
                flex-direction: column;
            }
            
            .status-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- هدر -->
        <div class="header">
            <h1>تست سیستم آمار پلیرها</h1>
            <p>بررسی عملکرد و وضعیت سیستم آمارگیری</p>
        </div>
        
        <!-- منوی ناوبری -->
        <div class="nav-menu">
            <ul>
                <li><a href="player-analytics-dashboard.php">داشبورد</a></li>
                <li><a href="player-analytics-report.php">گزارش تفصیلی</a></li>
                <li><a href="player-analytics-export.php">صادرات داده</a></li>
                <li><a href="player-analytics-test.php">تست سیستم</a></li>
            </ul>
        </div>
        
        <!-- وضعیت سیستم -->
        <div class="test-section">
            <h2>وضعیت سیستم</h2>
            <div class="status-grid">
                <div class="status-card <?php echo $db_status === 'success' ? 'status-success' : 'status-error'; ?>">
                    <h3><?php echo $db_status === 'success' ? '✅' : '❌'; ?></h3>
                    <p>اتصال به پایگاه داده</p>
                </div>
                
                <div class="status-card <?php echo $stats['total_clicks'] > 0 ? 'status-success' : 'status-warning'; ?>">
                    <h3><?php echo $stats['total_clicks'] > 0 ? '✅' : '⚠️'; ?></h3>
                    <p>جمع‌آوری داده</p>
                </div>
                
                <div class="status-card status-info">
                    <h3>ℹ️</h3>
                    <p>سیستم آماده</p>
                </div>
                
                <div class="status-card status-info">
                    <h3>📊</h3>
                    <p>آمار فعال</p>
                </div>
            </div>
        </div>
        
        <!-- آمار کلی -->
        <div class="test-section">
            <h2>آمار کلی</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <h4><?php echo number_format($stats['total_clicks']); ?></h4>
                    <p>تعداد کل کلیک‌ها</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format($stats['unique_sessions']); ?></h4>
                    <p>جلسات منحصر به فرد</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format($stats['unique_players']); ?></h4>
                    <p>پلیرهای منحصر به فرد</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format($stats['by_device']['mobile']); ?></h4>
                    <p>کلیک‌های موبایل</p>
                </div>
                <div class="stat-item">
                    <h4><?php echo number_format($stats['by_device']['desktop']); ?></h4>
                    <p>کلیک‌های دسکتاپ</p>
                </div>
            </div>
        </div>
        
        <!-- آمار بر اساس نوع عمل -->
        <div class="test-section">
            <h2>آمار بر اساس نوع عمل</h2>
            <table>
                <thead>
                    <tr>
                        <th>نوع عمل</th>
                        <th>تعداد</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats['by_action'] as $action => $count): ?>
                    <tr>
                        <td><?php echo esc_html($action); ?></td>
                        <td><?php echo number_format($count); ?></td>
                        <td>
                            <?php if ($count > 0): ?>
                                <span style="color: #28a745;">✅ فعال</span>
                            <?php else: ?>
                                <span style="color: #dc3545;">❌ غیرفعال</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- آمار بر اساس پلیر -->
        <div class="test-section">
            <h2>آمار بر اساس پلیر</h2>
            <table>
                <thead>
                    <tr>
                        <th>نام پلیر</th>
                        <th>تعداد کلیک</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats['by_player'] as $player => $count): ?>
                    <tr>
                        <td><?php echo esc_html($player); ?></td>
                        <td><?php echo number_format($count); ?></td>
                        <td>
                            <?php if ($count > 0): ?>
                                <span style="color: #28a745;">✅ فعال</span>
                            <?php else: ?>
                                <span style="color: #dc3545;">❌ غیرفعال</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- آخرین کلیک‌ها -->
        <div class="test-section">
            <h2>آخرین کلیک‌ها</h2>
            <table>
                <thead>
                    <tr>
                        <th>زمان</th>
                        <th>پلیر</th>
                        <th>عمل</th>
                        <th>دستگاه</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_clicks as $click): ?>
                    <tr>
                        <td><?php echo esc_html($click['timestamp']); ?></td>
                        <td><?php echo esc_html($click['player_title']); ?></td>
                        <td><?php echo esc_html($click['action']); ?></td>
                        <td><?php echo $click['is_mobile'] ? 'موبایل' : 'دسکتاپ'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- دستورات تست -->
        <div class="test-section">
            <div class="test-instructions">
                <h3>دستورات تست سیستم</h3>
                <p>برای تست کامل سیستم، مراحل زیر را انجام دهید:</p>
                <ul>
                    <li>به صفحه لندینگ بروید: <code>child-day-landing.php</code></li>
                    <li>روی دکمه‌های پلیر کلیک کنید (پخش، دانلود، علاقه‌مندی)</li>
                    <li>صدا را پخش و متوقف کنید</li>
                    <li>این صفحه را رفرش کنید تا آمار جدید را ببینید</li>
                    <li>در کنسول مرورگر <code>window.getPlayerStats()</code> را اجرا کنید</li>
                </ul>
            </div>
        </div>
        
        <!-- اطلاعات فنی -->
        <div class="test-section">
            <h2>اطلاعات فنی</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <h4>PHP</h4>
                    <p><?php echo PHP_VERSION; ?></p>
                </div>
                <div class="stat-item">
                    <h4>MySQL</h4>
                    <p><?php echo mysqli_get_server_info($analytics_db->get_connection()); ?></p>
                </div>
                <div class="stat-item">
                    <h4>جدول</h4>
                    <p><?php echo $analytics_db->get_table_name(); ?></p>
                </div>
                <div class="stat-item">
                    <h4>آخرین به‌روزرسانی</h4>
                    <p><?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
/**
 * صفحه گزارش آمار پلیرها
 * Player Analytics Report Page
 */

// اطمینان از امنیت
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

// بارگذاری handler آمار
require_once 'player-analytics-handler.php';

// دریافت پارامترهای فیلتر
$filter_days = isset($_GET['days']) ? intval($_GET['days']) : 7;
$filter_player = isset($_GET['player']) ? sanitize_text_field($_GET['player']) : '';
$filter_action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';

// ایجاد اتصال به پایگاه داده
$analytics_db = new PlayerAnalyticsDB();

// دریافت آمار
$overall_stats = $analytics_db->get_overall_stats();
$time_stats = $analytics_db->get_time_based_stats($filter_days);
$recent_clicks = $analytics_db->get_recent_clicks(100);

// فیلتر کردن آمار بر اساس پارامترها
$filtered_stats = $analytics_db->get_player_detailed_stats($filter_player);

?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>گزارش آمار پلیرها</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tahoma', 'Arial', sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .filter-row {
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .filter-group label {
            font-weight: bold;
            color: #555;
        }
        
        .filter-group select, .filter-group input {
            padding: 8px 12px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .filter-group select:focus, .filter-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            background: #667eea;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #5a6fd8;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            font-size: 2.5em;
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .stat-card p {
            color: #666;
            font-size: 1.1em;
        }
        
        .chart-container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .chart-title {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: #333;
        }
        
        .table-container {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 15px;
            text-align: right;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background: #f8f9fa;
            font-weight: bold;
            color: #555;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .export-buttons {
            text-align: center;
            margin: 30px 0;
        }
        
        .export-btn {
            background: #28a745;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 0 10px;
            transition: background 0.3s;
        }
        
        .export-btn:hover {
            background: #218838;
        }
        
        .export-btn.secondary {
            background: #6c757d;
        }
        
        .export-btn.secondary:hover {
            background: #5a6268;
        }
        
        @media (max-width: 768px) {
            .filter-row {
                flex-direction: column;
                align-items: stretch;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .container {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- هدر -->
        <div class="header">
            <h1>گزارش آمار پلیرها</h1>
            <p>آمار کامل کلیک‌ها و تعاملات کاربران با پلیرهای صوتی</p>
        </div>
        
        <!-- فیلترها -->
        <div class="filters">
            <form method="GET">
                <div class="filter-row">
                    <div class="filter-group">
                        <label for="days">بازه زمانی:</label>
                        <select name="days" id="days">
                            <option value="1" <?php echo $filter_days == 1 ? 'selected' : ''; ?>>امروز</option>
                            <option value="7" <?php echo $filter_days == 7 ? 'selected' : ''; ?>>هفته گذشته</option>
                            <option value="30" <?php echo $filter_days == 30 ? 'selected' : ''; ?>>ماه گذشته</option>
                            <option value="90" <?php echo $filter_days == 90 ? 'selected' : ''; ?>>سه ماه گذشته</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label for="player">پلیر:</label>
                        <select name="player" id="player">
                            <option value="">همه پلیرها</option>
                            <?php foreach ($overall_stats['by_player'] as $player => $count): ?>
                            <option value="<?php echo esc_attr($player); ?>" <?php echo $filter_player == $player ? 'selected' : ''; ?>>
                                <?php echo esc_html($player); ?> (<?php echo $count; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label for="action">نوع عمل:</label>
                        <select name="action" id="action">
                            <option value="">همه اعمال</option>
                            <?php foreach ($overall_stats['by_action'] as $action => $count): ?>
                            <option value="<?php echo esc_attr($action); ?>" <?php echo $filter_action == $action ? 'selected' : ''; ?>>
                                <?php echo esc_html($action); ?> (<?php echo $count; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn">اعمال فیلتر</button>
                </div>
            </form>
        </div>
        
        <!-- آمار کلی -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo number_format($overall_stats['total_clicks']); ?></h3>
                <p>تعداد کل کلیک‌ها</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($overall_stats['unique_sessions']); ?></h3>
                <p>جلسات منحصر به فرد</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($overall_stats['unique_players']); ?></h3>
                <p>پلیرهای منحصر به فرد</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($overall_stats['by_device']['mobile']); ?></h3>
                <p>کلیک‌های موبایل</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($overall_stats['by_device']['desktop']); ?></h3>
                <p>کلیک‌های دسکتاپ</p>
            </div>
        </div>
        
        <!-- آمار بر اساس نوع عمل -->
        <div class="chart-container">
            <h2 class="chart-title">آمار بر اساس نوع عمل</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>نوع عمل</th>
                            <th>تعداد</th>
                            <th>درصد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_actions = array_sum($overall_stats['by_action']);
                        foreach ($overall_stats['by_action'] as $action => $count): 
                            $percentage = $total_actions > 0 ? round(($count / $total_actions) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><?php echo esc_html($action); ?></td>
                            <td><?php echo number_format($count); ?></td>
                            <td><?php echo $percentage; ?>%</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- آمار بر اساس پلیر -->
        <div class="chart-container">
            <h2 class="chart-title">آمار بر اساس پلیر</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>نام پلیر</th>
                            <th>تعداد کلیک</th>
                            <th>درصد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_players = array_sum($overall_stats['by_player']);
                        foreach ($overall_stats['by_player'] as $player => $count): 
                            $percentage = $total_players > 0 ? round(($count / $total_players) * 100, 1) : 0;
                        ?>
                        <tr>
                            <td><?php echo esc_html($player); ?></td>
                            <td><?php echo number_format($count); ?></td>
                            <td><?php echo $percentage; ?>%</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- آمار زمانی -->
        <div class="chart-container">
            <h2 class="chart-title">آمار زمانی (<?php echo $filter_days; ?> روز گذشته)</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>تاریخ</th>
                            <th>تعداد کلیک</th>
                            <th>جلسات منحصر به فرد</th>
                            <th>پلیرهای منحصر به فرد</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($time_stats as $stat): ?>
                        <tr>
                            <td><?php echo esc_html($stat['date']); ?></td>
                            <td><?php echo number_format($stat['total_clicks']); ?></td>
                            <td><?php echo number_format($stat['unique_sessions']); ?></td>
                            <td><?php echo number_format($stat['unique_players']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- آخرین کلیک‌ها -->
        <div class="chart-container">
            <h2 class="chart-title">آخرین کلیک‌ها</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>زمان</th>
                            <th>پلیر</th>
                            <th>عمل</th>
                            <th>دستگاه</th>
                            <th>شناسه جلسه</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_clicks as $click): ?>
                        <tr>
                            <td><?php echo esc_html($click['timestamp']); ?></td>
                            <td><?php echo esc_html($click['player_title']); ?></td>
                            <td><?php echo esc_html($click['action']); ?></td>
                            <td><?php echo $click['is_mobile'] ? 'موبایل' : 'دسکتاپ'; ?></td>
                            <td><?php echo esc_html(substr($click['session_id'], -8)); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- دکمه‌های صادرات -->
        <div class="export-buttons">
            <button class="export-btn" onclick="exportToCSV()">صادرات CSV</button>
            <button class="export-btn secondary" onclick="exportToJSON()">صادرات JSON</button>
            <button class="export-btn secondary" onclick="printReport()">چاپ گزارش</button>
        </div>
    </div>
    
    <script>
        // صادرات به CSV
        function exportToCSV() {
            const data = <?php echo json_encode($overall_stats); ?>;
            const csv = convertToCSV(data);
            downloadFile(csv, 'player-analytics.csv', 'text/csv');
        }
        
        // صادرات به JSON
        function exportToJSON() {
            const data = <?php echo json_encode($overall_stats); ?>;
            const json = JSON.stringify(data, null, 2);
            downloadFile(json, 'player-analytics.json', 'application/json');
        }
        
        // چاپ گزارش
        function printReport() {
            window.print();
        }
        
        // تبدیل داده به CSV
        function convertToCSV(data) {
            let csv = 'نوع آمار,مقدار\n';
            csv += 'تعداد کل کلیک‌ها,' + data.total_clicks + '\n';
            csv += 'جلسات منحصر به فرد,' + data.unique_sessions + '\n';
            csv += 'پلیرهای منحصر به فرد,' + data.unique_players + '\n';
            csv += 'کلیک‌های موبایل,' + data.by_device.mobile + '\n';
            csv += 'کلیک‌های دسکتاپ,' + data.by_device.desktop + '\n';
            return csv;
        }
        
        // دانلود فایل
        function downloadFile(content, filename, mimeType) {
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            link.click();
            URL.revokeObjectURL(url);
        }
    </script>
</body>
</html>
